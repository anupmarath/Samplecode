-- Databricks notebook source
-- MAGIC %python
-- MAGIC from pyspark.sql import HiveContext
-- MAGIC hiveCtx = HiveContext(sc)
-- MAGIC import sqlite3 as sq
-- MAGIC import pandas as pd
-- MAGIC import numpy as np
-- MAGIC import time
-- MAGIC import re
-- MAGIC from pandas import ExcelWriter

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC --select * from db_landing.by_store_by_period_garn limit 10;
-- MAGIC --select * from db_landing.by_store_by_period_garn where year  = '2018';
-- MAGIC select * from db_work.ab  limit 10 ;

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC select count(*),store_number  from db_landing.by_store_by_period_garn group by store_number order by store_number  desc;

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC select COUNT(*) from (
-- MAGIC select  * from db_landing.by_store_by_period_pf_ft )

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC Drop table db_work.ab;
-- MAGIC create table db_work.ab  as SELECT *
-- MAGIC     FROM (
-- MAGIC         SELECT store_number,
-- MAGIC    
-- MAGIC         store_desc
-- MAGIC    
-- MAGIC 
-- MAGIC ,AVG(garn_usd)as garn_usd
-- MAGIC ,AVG(garn_ee_cnt)as garn_ee_cnt
-- MAGIC 
-- MAGIC from db_landing.by_store_by_period_garn
-- MAGIC 
-- MAGIC Group By store_number, store_desc,year ORDER BY  year = '2018' );
-- MAGIC               

-- COMMAND ----------

-- MAGIC %python
-- MAGIC df=hiveCtx.sql("select * from db_work.ab ")
-- MAGIC df.toPandas().to_csv ('/dbfs/mnt/shrink_data/by_store_by_period_garn.csv',header='True', encoding="utf-8")
